package com.example.ajeya.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MultiPlayer extends AppCompatActivity {
    EditText ques,ans;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi_player);
        ques=(EditText) findViewById(R.id.editTextques);
        ans=(EditText)findViewById(R.id.editTextans);
    }
    public void enterquesfunc(View view)
    {
        String q1,a1;
        q1=ques.getText().toString();
        a1=ans.getText().toString();
        Intent intent = new Intent(getApplicationContext(), MultiplayerActivity1.class);
        intent.putExtra("QUESTION", q1);
        intent.putExtra("ANSWER",a1);
        startActivity(intent);
    }
}
