package com.example.ajeya.project1;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button setquestionbtn;
    Button singleplayer;
    TextView highscore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setquestionbtn = (Button)findViewById(R.id.quesbtn);
        singleplayer = (Button)findViewById(R.id.singleplayer);
        highscore = (TextView)findViewById(R.id.highscore);
        Scores s=new Scores();
        int i=s.getHighscore();
        highscore.setText("HIGH SCORE: "+i);
        s.initializegamescore();
    }
    void setquestionfunc(View view)
    {
        Intent i = new Intent(getApplicationContext(), SetQuestion.class);
        startActivity(i);
    }
    void singleplayerfunc(View view)
    {
        Intent i = new Intent(getApplicationContext(), SinglePlayer.class);
        startActivity(i);
    }
    void multiplayerfunc(View view)
    {
        Intent i = new Intent(getApplicationContext(), MultiPlayer.class);
        startActivity(i);
    }
    void exitfunc(View view)
    {
        finish();

    }
}