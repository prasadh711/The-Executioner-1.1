package com.example.ajeya.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

public class MultiplayerActivity1 extends AppCompatActivity {
    TextView questxt,anstxt,chartxt;
    String answer,enteredanswer="                           ";
    char charecter;
    int score=100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplayer1);
        String s1=getIntent().getStringExtra("QUESTION");
        answer=getIntent().getStringExtra("ANSWER");
        TextView t1=(TextView)findViewById(R.id.textViewtemp);
        questxt=(TextView)findViewById(R.id.questxt1);
        anstxt=(TextView)findViewById(R.id.anstxt1);
        chartxt=(TextView)findViewById(R.id.chartxt1);
        questxt.setText(s1);
        initialize();
    }
    void initialize()
    {
        int count=answer.length();
        char[] enteredanswer1=enteredanswer.toCharArray();
        for(int i=0;i<count;i++) {
            if(answer.charAt(i)==' ')
                enteredanswer1[i]=' ';
            else
                enteredanswer1[i]='-';
        }
        enteredanswer = String.valueOf(enteredanswer1);
        anstxt.setText(enteredanswer);
    }
    public boolean dispatchKeyEvent(KeyEvent KEvent) {
        int keyaction = KEvent.getAction();

        if(keyaction == KeyEvent.ACTION_DOWN)
        {
            int keycode = KEvent.getKeyCode();
            int keyunicode = KEvent.getUnicodeChar(KEvent.getMetaState() );
            char character = (char) keyunicode;
            charecter=character;
            chartxt.setText(" "+character);
        }
        return super.dispatchKeyEvent(KEvent);
    }
    public void checkanswer1(View view)
    {
        int flag=0;
        char[] enteredanswer1=enteredanswer.toCharArray();
        String actualanswer=" ";
        int c=answer.length();
        for(int i=0;i<c;i++)
        {
            if(charecter == answer.charAt(i))
            {
                flag=1;
                enteredanswer1[i]=charecter;
            }
        }
        if(flag==0)
            score=score-10;
        enteredanswer=String.valueOf(enteredanswer1);
        actualanswer = enteredanswer.substring(0,c);
        anstxt.setText(enteredanswer+"     "+"SCORE: "+score);
        if(actualanswer.equals(answer)) {
            Intent intent = new Intent(getApplicationContext(), MultiplayerScores.class);
            intent.putExtra("SCORE"," "+score);
            intent.putExtra("ANSWER",answer);
            startActivity(intent);
        }
    }
}
