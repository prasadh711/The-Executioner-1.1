package com.example.ajeya.project1;


public class Scores {
    public static int highscore = 0;
    public static int gamescore = 0;
    public static int gamecount = 0;
    public Scores(){}
    public int getHighscore()
    {
        return highscore;
    }
    public void setHighscore(int i)
    {
        highscore=i;
    }
    public void initializegamescore()
    {
        gamescore=0;
        gamecount=0;
    }
    public int getGamescore()
    {
        return gamescore;
    }
    public void setGamescore(int i)
    {
        gamescore=i;
    }
    public void incrementcount()
    {
        gamecount++;
    }
    public int getGamecount()
    {
        return gamecount;
    }
}
