package com.example.ajeya.project1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SetQuestion extends AppCompatActivity {
    TextView temp;
    EditText q;
    EditText a;
    Button b;
    DBHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_question);
        q=(EditText)findViewById(R.id.question1);
        a=(EditText)findViewById(R.id.answer1);
        b=(Button)findViewById(R.id.enterqbtn);
        /*DBHandler1 db = new DBHandler1(this);
        Log.d("Insert","Inserting...");
        db.addQuestions(new Questions("Which city is capital of India","New Delhi"));
        Questions q;
        List<Questions> contacts = db.getAllQurstion();
        String log ="";
        for (Questions cn : contacts) {
            log = log +"ID"+cn.getId()+" ,Name: " + cn.getQuestion() + " ,Phone: " +cn.getAnswer();
            log = log + "\n";
        }
        q=db.getQuestion(1);
        int i = db.getQuestioinCount();
        temp.setText("Count:"+" "+q.getQuestion()+q.getAnswer());
        //temp.setText(""+i);*/
    }
    public void entertodatabase(View view)
    {
        DBHandler1 db = new DBHandler1(this);
        Log.d("Insert","Inserting...");
        String q1=q.getText().toString();
        String a1=a.getText().toString();
        db.addQuestions(new Questions(q1,a1));
        List<Questions> contacts = db.getAllQuestion();
        String log ="";
        temp=(TextView)findViewById(R.id.temptxt2);
        for (Questions cn : contacts) {
            log = log +"ID"+cn.getId()+" ,Name: " + cn.getQuestion() + " ,Phone: " +cn.getAnswer();
            log = log + "\n";
        }
        int i=db.getCount();
        Toast.makeText(this,"Question Inserted Successfully",Toast.LENGTH_LONG);
    }
}
