package com.example.ajeya.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ShowScore extends AppCompatActivity {
    TextView showscore;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_score);
        showscore = (TextView)findViewById(R.id.showscoretxt1);
        Scores s=new Scores();
        int gs = s.getGamescore();
        showscore.setText("YOUR GAMESCORE IS : "+gs);
        s.incrementcount();
        if(s.getGamecount()==2)
        {
            flag=1;
            showscore.setText("YOUR TOTAL GAMESCORE IS :"+gs+"\nHIGH SCORE IS : "+s.getHighscore());
        }
    }
    public void continuegamefunc(View view)
    {
        if(flag==0) {
            Intent i = new Intent(getApplicationContext(), SinglePlayer.class);
            startActivity(i);
        }
        else{
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }
    }
}
