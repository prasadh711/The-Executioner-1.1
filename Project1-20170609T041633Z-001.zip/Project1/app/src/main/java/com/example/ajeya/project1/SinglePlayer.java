package com.example.ajeya.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class SinglePlayer extends AppCompatActivity {
    DBHandler1 db=new DBHandler1(this);
    TextView questxt;
    TextView temp;
    TextView scoretxt;
    TextView chartxt;
    TextView displaytxt;
    char charecter;
    String answer;
    int score=100;
    int check=1;
    int gamescore;
    String enteredanswer="                                   ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_player);
        questxt = (TextView) findViewById(R.id.questiontxt);
        temp = (TextView) findViewById(R.id.sptxt2);
        scoretxt = (TextView) findViewById(R.id.scoretxt);
        chartxt = (TextView) findViewById(R.id.charectertxt);
        displaytxt=(TextView)findViewById(R.id.displaytxt);
        setQuestion();
        initialize();
    }
    public void setQuestion()
    {
        Random r=new Random();
        Questions q;
        int count;
        int id=r.nextInt(1000);
        count=db.getCount();
        id=(id%count)+1;
        q=db.getQuestion(id);
        questxt.setText(q.getQuestion().toUpperCase());
        answer=q.getAnswer().toLowerCase();
    }

    public boolean dispatchKeyEvent(KeyEvent KEvent) {
        /*String temptext="key pressed:"+String.valueOf(event.getKeyCode());
        temp.setText(temptext);
        return super.dispatchKeyEvent(event);*/

        int keyaction = KEvent.getAction();

        if(keyaction == KeyEvent.ACTION_DOWN)
        {
            int keycode = KEvent.getKeyCode();
            int keyunicode = KEvent.getUnicodeChar(KEvent.getMetaState() );
            char character = (char) keyunicode;
            charecter=character;
            chartxt.setText(" "+character);
        }
        return super.dispatchKeyEvent(KEvent);
    }
    void initialize()
    {
        int count=answer.length();
        char[] enteredanswer1=enteredanswer.toCharArray();
        for(int i=0;i<count;i++) {
            if(answer.charAt(i)==' ')
                enteredanswer1[i]=' ';
            else
                enteredanswer1[i]='_';
        }
        enteredanswer = String.valueOf(enteredanswer1);
        temp.setText(enteredanswer);
    }
    public void checkanswer(View view)
    {
        Scores s=new Scores();
        int max=s.getHighscore();
        int gamescore = s.getGamescore();
        int flag=0;
        char[] enteredanswer1=enteredanswer.toCharArray();
        String actualanswer=" ";
        int c=answer.length();
        for(int i=0;i<c;i++)
        {
            if(charecter == answer.charAt(i))
            {
                flag=1;
                enteredanswer1[i]=charecter;
            }
        }
        if(flag==0)
            score=score-10;
        enteredanswer=String.valueOf(enteredanswer1);
        actualanswer = enteredanswer.substring(0,c);
        temp.setText(enteredanswer);
        if(actualanswer.equals(answer)) {
            displaytxt.setText("CORRECT ANSWER");
            gamescore=score+gamescore;
            s.setGamescore(gamescore);
            if(max<gamescore)
                s.setHighscore(gamescore);
            Intent i = new Intent(getApplicationContext(), ShowScore.class);
            startActivity(i);
        }
        scoretxt.setText("SCORE:"+score+"||GAMESCORE: "+gamescore);
    }
}
