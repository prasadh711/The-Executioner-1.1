package com.example.ajeya.project1;

public class Questions {
    String q;
    String answer;
    int id;
    public Questions(){}
    public Questions(String q,String answer){
        this.q=q;
        this.answer=answer;
    }
    public Questions(int id,String q,String answer){
        this.q=q;
        this.answer=answer;
        this.id=id;
    }

    public int getId()
    {
        return this.id;
    }
    public String getQuestion()
    {
        return this.q;
    }
    public String getAnswer()
    {
        return this.answer;
    }
    public void setQ(String q)
    {
        this.q=q;
    }
    public void setAnswer(String answer)
    {
        this.answer=answer;
    }
    public void setId(int id)
    {
        this.id=id;
    }
}
