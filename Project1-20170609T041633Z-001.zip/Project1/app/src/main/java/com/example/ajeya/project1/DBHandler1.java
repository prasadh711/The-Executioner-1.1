package com.example.ajeya.project1;
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DBHandler1 extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "QuestionDB";
    private static final String TABLE_QUIZ = "Quiz";
    private static final String KEY_ID = "id";
    private static final String KEY_QUESTION = "question";
    private static final String KEY_ANSWER = "answer";

    public DBHandler1(Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_QUIZ + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_QUESTION + " TEXT,"
                + KEY_ANSWER + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUIZ);
        onCreate(db);
    }
    void addQuestions(Questions q) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_QUESTION, q.getQuestion()); // Contact Name
        values.put(KEY_ANSWER, q.getAnswer()); // Contact Phone

        // Inserting Row
        db.insert(TABLE_QUIZ, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }
    public int getCount() {
        int count;
        String countQuery = "SELECT  * FROM " + TABLE_QUIZ;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        try {
            count = cursor.getCount();
            return count;
        }finally {
            if(cursor!=null)
                cursor.close();
        }
    }
    Questions getQuestion(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_QUIZ, new String[] { KEY_ID,
                        KEY_QUESTION, KEY_ANSWER }, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Questions q = new Questions(cursor.getString(1), cursor.getString(2));
        // return contact
        return q;
    }
    public List<Questions> getAllQuestion() {
        List<Questions> QuestionList = new ArrayList<Questions>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_QUIZ;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Questions contact = new Questions();
                contact.setId(Integer.parseInt(cursor.getString(0)));
                contact.setQ(cursor.getString(1));
                contact.setAnswer(cursor.getString(2));
                // Adding contact to list
                QuestionList.add(contact);
            } while (cursor.moveToNext());
        }

        // return contact list
        return QuestionList;
    }
}
