package com.example.ajeya.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MultiplayerScores extends AppCompatActivity {
    TextView disptxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multiplayer_scores);
        String s1=getIntent().getStringExtra("SCORE");
        String s2=getIntent().getStringExtra("ANSWER");
        disptxt=(TextView)findViewById(R.id.disptxt1);
        disptxt.setText("THE ANSWER IS "+s2+"\nYOUR SCORE IS "+s1);
    }
    public void newgamefunc(View view)
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}
